# pygame setup
import pygame as pg

pg.init()
screen = pg.display.set_mode([800, 800])
pg.display.set_caption("Example code for the cursors module")

# create a system cursor
system = pg.cursors.Cursor(pg.SYSTEM_CURSOR_HAND)

# create bitmap cursors

cursors = [system]
cursor_index = 0

pg.mouse.set_cursor(cursors[cursor_index])

clock = pg.time.Clock()

board = pg.image.load('board.png')

black_rock = pg.image.load('black_rock.jpeg')
black_pawn = pg.image.load('black_pawn.png')
black_bishop = pg.image.load('black_bishop.jpeg')
black_king = pg.image.load('black_king.jpeg')
black_queen = pg.image.load('black_queen.jpeg')
black_knight = pg.image.load('black_knight.jpeg')

white_rock = pg.image.load('white_rock.png')
white_pawn = pg.image.load('white_pawn.png')
white_bishop = pg.image.load('white_bishop.png')
white_king = pg.image.load('white_king.png')
white_queen = pg.image.load('white_queen.png')
white_knight = pg.image.load('white_knight.png')

black_rock = pg.transform.scale(black_rock, (100, 100))
black_pawn = pg.transform.scale(black_pawn, (100, 100))
black_bishop = pg.transform.scale(black_bishop, (100, 100))
black_queen = pg.transform.scale(black_queen, (100, 100))
black_knight = pg.transform.scale(black_knight, (100, 100))
black_king = pg.transform.scale(black_king, (100,100))

white_rock = pg.transform.scale(white_rock, (100, 100))
white_pawn = pg.transform.scale(white_pawn, (100, 100))
white_bishop = pg.transform.scale(white_bishop, (100, 100))
white_queen = pg.transform.scale(white_queen, (100, 100))
white_knight = pg.transform.scale(white_knight, (100, 100))
white_king = pg.transform.scale(white_king, (100,100))


board = pg.transform.scale(board, (800, 800))

bg = (127,127,127)

board_pos = board.get_rect()

board_pos.center = 400, 400

screen.blit(board, board_pos)

knight_b_1_pos = black_knight.get_rect()
knight_b_2_pos = black_knight.get_rect()

queen_b_pos =black_queen.get_rect()

king_b_pos = black_king.get_rect()

bishop_b_1_pos = black_bishop.get_rect()
bishop_b_2_pos = black_bishop.get_rect()

knight_w_1_pos = white_knight.get_rect()
knight_w_2_pos = white_knight.get_rect()

queen_w_pos =white_queen.get_rect()

king_w_pos = white_king.get_rect()

bishop_w_1_pos = white_bishop.get_rect()
bishop_w_2_pos = white_bishop.get_rect()

rock_b_1_pos =black_rock.get_rect()
rock_b_2_pos =black_rock.get_rect()
pawn_b_1_pos =black_pawn.get_rect()
pawn_b_2_pos =black_pawn.get_rect()
pawn_b_3_pos =black_pawn.get_rect()
pawn_b_4_pos =black_pawn.get_rect()
pawn_b_5_pos =black_pawn.get_rect()
pawn_b_6_pos =black_pawn.get_rect()
pawn_b_7_pos =black_pawn.get_rect()
pawn_b_8_pos =black_pawn.get_rect()

rock_w_1_pos =white_rock.get_rect()
rock_w_2_pos =white_rock.get_rect()

pawn_w_1_pos =white_pawn.get_rect()
pawn_w_2_pos =white_pawn.get_rect()
pawn_w_3_pos =white_pawn.get_rect()
pawn_w_4_pos =white_pawn.get_rect()
pawn_w_5_pos =white_pawn.get_rect()
pawn_w_6_pos =white_pawn.get_rect()
pawn_w_7_pos =white_pawn.get_rect()
pawn_w_8_pos =white_pawn.get_rect()

bishop_w_1_pos.center = 250,750
bishop_w_2_pos.center = 550,750

knight_w_1_pos.center = 150,750
knight_w_2_pos.center = 650,750

king_w_pos.center = 450, 750
queen_w_pos.center = 350, 750

bishop_b_1_pos.center = 250,50
bishop_b_2_pos.center = 550,50

knight_b_1_pos.center = 150,50
knight_b_2_pos.center = 650,50

king_b_pos.center = 450, 50
queen_b_pos.center = 350, 50

rock_b_1_pos.center = 50,50
rock_b_2_pos.center = 750,50

pawn_b_1_pos.center = 50, 150
pawn_b_2_pos.center = 150, 150
pawn_b_3_pos.center = 250, 150
pawn_b_4_pos.center = 350, 150
pawn_b_5_pos.center = 450, 150
pawn_b_6_pos.center = 550, 150
pawn_b_7_pos.center = 650, 150
pawn_b_8_pos.center = 750, 150

rock_w_1_pos.center = 50,750
rock_w_2_pos.center = 750,750

pawn_w_1_pos.center = 50, 650
pawn_w_2_pos.center = 150, 650
pawn_w_3_pos.center = 250, 650
pawn_w_4_pos.center = 350, 650
pawn_w_5_pos.center = 450, 650
pawn_w_6_pos.center = 550, 650
pawn_w_7_pos.center = 650, 650
pawn_w_8_pos.center = 750, 650

screen.blit(black_bishop, bishop_b_1_pos)
screen.blit(black_bishop, bishop_b_2_pos)

screen.blit(black_knight, knight_b_1_pos)
screen.blit(black_knight, knight_b_2_pos)

screen.blit(black_queen, queen_b_pos)

screen.blit(black_king, king_b_pos)

screen.blit(white_bishop, bishop_w_1_pos)
screen.blit(white_bishop, bishop_w_2_pos)

screen.blit(white_knight, knight_w_1_pos)
screen.blit(white_knight, knight_w_2_pos)

screen.blit(white_queen, queen_w_pos)

screen.blit(white_king, king_w_pos)

screen.blit(black_rock, rock_b_1_pos)
screen.blit(black_rock, rock_b_2_pos)
screen.blit(black_pawn,pawn_b_1_pos)
screen.blit(black_pawn,pawn_b_2_pos)
screen.blit(black_pawn,pawn_b_3_pos)
screen.blit(black_pawn,pawn_b_4_pos)
screen.blit(black_pawn,pawn_b_5_pos)
screen.blit(black_pawn,pawn_b_6_pos)
screen.blit(black_pawn,pawn_b_7_pos)
screen.blit(black_pawn,pawn_b_8_pos)

screen.blit(white_rock, rock_w_1_pos)
screen.blit(white_rock, rock_w_2_pos)

screen.blit(white_pawn,pawn_w_1_pos)
screen.blit(white_pawn,pawn_w_2_pos)
screen.blit(white_pawn,pawn_w_3_pos)
screen.blit(white_pawn,pawn_w_4_pos)
screen.blit(white_pawn,pawn_w_5_pos)
screen.blit(white_pawn,pawn_w_6_pos)
screen.blit(white_pawn,pawn_w_7_pos)
screen.blit(white_pawn,pawn_w_8_pos)

rock_moves = ([x * 100, rock_yposition] , [rock_xposition , y * 100])
if(abs(x * 100 - rock_xposition) < 800 and abs(y * 100 - rock_yposition) < 800):
    if(x * 100 - rock_xposition > 0 and y * 100 - rock_yposition == 0):
        moves.append([(x * 100, rock_yposition)])

king_moves = ([king_xposition + 100, king_yposition],
               [king_xposition - 100, king_yposition],
               [king_xposition, king_yposition - 100],
               [king_xposition, king_yposition + 100],
               [king_xposition + 100, king_yposition + 100],
               [king_xposition - 100, king_yposition - 100],
               [king_xposition - 100, king_yposition + 100],
               [king_xposition + 100, king_yposition - 100]
              )

if (abs(x * 100 - king_xposition) <= 100 and abs(y * 100 - king_yposition) <= 100):
        if x * 100 - king_xposition == 100 and y * 100 - king_yposition == 0:
            moves.append([king_xposition + 100, king_yposition])
        elif x * 100 - king_xposition == -100 and y * 100 - king_yposition == 0:
            moves.append([king_xposition - 100, king_yposition])
        elif x * 100 - king_xposition == 0 and y * 100 - king_yposition == -100:
            moves.append([king_xposition, king_yposition - 100])
        elif x * 100 - king_xposition == 0 and y * 100 - king_yposition == 100:
            moves.append([king_xposition, king_yposition + 100])
        elif x * 100 - king_xposition == 100 and y * 100 - king_yposition == 100:
            moves.append([king_xposition + 100, king_yposition + 100])
        elif x * 100 - king_xposition == -100 and y * 100 - king_yposition == -100:
            moves.append([king_xposition - 100, king_yposition - 100])
        elif x * 100 - king_xposition == -100 and y * 100 - king_yposition == 100:
            moves.append([king_xposition - 100, king_yposition + 100])
        elif x * 100 - king_xposition == 100 and y * 100 - king_yposition == -100:
            moves.append([king_xposition + 100, king_yposition - 100])

queen_moves =([x * 100, queen_yposition],
            [queen_xposition , y * 100],
            [x * 100 , y * 100]
               )
if(x * 100 < 700 and y * 100 < 700):
    if(abs(queen_xposition - 100 * x) == abs(queen_yposition - 100 * y) ):
        moves.append([x * 100 , y * 100])
    elif(abs(x * 100 - queen_xposition) > 0 ):
        moves.append([x * 100, queen_yposition])
    elif(abs(y * 100 - queen_yposition) > 0 ):
        moves.append([queen_xposition , y * 100])
knight_moves([knight_xposition + 200, knight_yposition + 100],
             [knight_xposition + 200, knight_yposition - 100],
             [knight_xposition + 100, knight_yposition - 200],
             [knight_xposition - 100, knight_yposition - 200],
             [knight_xposition + 100, knight_yposition + 200],
             [knight_xposition - 100, knight_yposition + 200],
             [knight_xposition - 200, knight_yposition + 100],
             [knight_xposition - 200, knight_yposition - 100],
             )
if(x * 100 < 700 and y * 100 < 700):
    if(knight_xposition - x * 100 == 200 and knight_yposition - y * 100 == 100):
        move.append([knight_xposition + 200, knight_yposition + 100])
    elif(knight_xposition - x * 100 == 200 and knight_yposition - y * 100 == -100):
        move.append([knight_xposition + 200, knight_yposition - 100])
    elif(knight_xposition - x * 100 == 100 and knight_yposition - y * 100 == -200):
        move.append([knight_xposition + 100, knight_yposition - 200])
    elif(knight_xposition - x * 100 == -100 and knight_yposition - y * 100 == -200):
        move.append([knight_xposition - 100, knight_yposition - 200])
    elif(knight_xposition - x * 100 == 100 and knight_yposition - y * 100 == 200):
        move.append([knight_xposition + 100, knight_yposition + 200])
    elif(knight_xposition - x * 100 == -100 and knight_yposition - y * 100 == 200):
        move.append([knight_xposition - 100, knight_yposition + 200])
    elif(knight_xposition - x * 100 == -200 and knight_yposition - y * 100 == 100):
        move.append([knight_xposition -200, knight_yposition + 100])
    elif(knight_xposition - x * 100 == -200 and knight_yposition - y * 100 == -100):
        move.append([knight_xposition - 200, knight_yposition - 100])

bishop_moves = ([x * 100, y*100])
if(x * 100 < 700 and y * 100 < 700):
    if(abs(bishop_xposition - 100 * x) == abs(bishop_yposition - 100 * y) ):
        moves.append([x * 100 , y * 100])

pawn_moves([pawn_xposition - 100, pawn_yposition],
           [pawn_xposition - 100, pawn_yposition - 100],
           [pawn_xposition + 100, pawn_yposition - 100],
           [pawn_xposition + 100, pawn_yposition],
           [pawn_xposition + 100, pawn_yposition + 100],
           [pawn_xposition - 100, pawn_yposition + 100],
           )
if(abs(x * 100 - pawn_xposition) == 100):
    if()
going = True
while going:
    
    clock.tick(60)
    pg.display.flip()
    x , y = pg.mouse.get_pos()
    x = (x // 100)
    y = (y // 100)
    print(x, y)
    for event in pg.event.get():
        if event.type == pg.QUIT or (event.type == pg.KEYDOWN and event.key == pg.K_ESCAPE):
            going = False

pg.quit()