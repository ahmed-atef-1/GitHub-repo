import pygame as pg
from pygame.locals import *

# Initialize Pygame
pg.init()
screen = pg.display.set_mode([800, 800])
pg.display.set_caption("Chess Game")

# Load images
board = pg.image.load('board.png')
pieces = {
    'black_rock': pg.image.load('black_rock.jpeg'),
    'black_pawn': pg.image.load('black_pawn.png'),
    'black_bishop': pg.image.load('black_bishop.jpeg'),
    'black_king': pg.image.load('black_king.jpeg'),
    'black_queen': pg.image.load('black_queen.jpeg'),
    'black_knight': pg.image.load('black_knight.jpeg'),
    'white_rock': pg.image.load('white_rock.png'),
    'white_pawn': pg.image.load('white_pawn.png'),
    'white_bishop': pg.image.load('white_bishop.png'),
    'white_king': pg.image.load('white_king.png'),
    'white_queen': pg.image.load('white_queen.png'),
    'white_knight': pg.image.load('white_knight.png')
}

# Scale images
for key in pieces:
    pieces[key] = pg.transform.scale(pieces[key], (100, 100))

board = pg.transform.scale(board, (800, 800))

# Piece positions
piece_positions = {
    'black': {
        'rock': [(0, 0), (7, 0)],
        'knight': [(1, 0), (6, 0)],
        'bishop': [(2, 0), (5, 0)],
        'queen': [(3, 0)],
        'king': [(4, 0)],
        'pawn': [(i, 1) for i in range(8)]
    },
    'white': {
        'rock': [(0, 7), (7, 7)],
        'knight': [(1, 7), (6, 7)],
        'bishop': [(2, 7), (5, 7)],
        'queen': [(3, 7)],
        'king': [(4, 7)],
        'pawn': [(i, 6) for i in range(8)]
    }
}

selected_piece = None
turn = 'white'

def draw_board():
    screen.blit(board, (0, 0))
    for color in piece_positions:
        for piece in piece_positions[color]:
            for pos in piece_positions[color][piece]:
                piece_key = f'{color}_{piece}'
                screen.blit(pieces[piece_key], (pos[0] * 100, pos[1] * 100))

def get_piece_at(x, y):
    for color in piece_positions:
        for piece in piece_positions[color]:
            for pos in piece_positions[color][piece]:
                if pos == (x, y):
                    return (color, piece, pos)
    return None

def move_piece(color, piece, old_pos, new_pos):
    piece_positions[color][piece].remove(old_pos)
    piece_positions[color][piece].append(new_pos)

def capture_piece(capturing_color, capturing_piece, capturing_pos, captured_pos):
    captured_color, captured_piece, _ = get_piece_at(*captured_pos)
    piece_positions[captured_color][captured_piece].remove(captured_pos)
    move_piece(capturing_color, capturing_piece, capturing_pos, captured_pos)

# Main game loop
running = True
clock = pg.time.Clock()
while running:
    for event in pg.event.get():
        if event.type == QUIT:
            running = False
        elif event.type == MOUSEBUTTONDOWN:
            x, y = event.pos
            x //= 100
            y //= 100
            if selected_piece:
                piece_color, piece_type, old_pos = selected_piece
                target_piece = get_piece_at(x, y)
                if target_piece and target_piece[0] != piece_color:
                    capture_piece(piece_color, piece_type, old_pos, (x, y))
                else:
                    move_piece(piece_color, piece_type, old_pos, (x, y))
                selected_piece = None
                turn = 'black' if turn == 'white' else 'white'
            else:
                piece = get_piece_at(x, y)
                if piece and piece[0] == turn:
                    selected_piece = piece

    draw_board()
    pg.display.flip()
    clock.tick(60)

pg.quit()
